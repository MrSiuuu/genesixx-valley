/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}", // très important pour qu'il scanne tous tes fichiers React
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
