import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useAdmin } from '../hooks/useAdmin';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { motion } from 'framer-motion';


function Home() {
  const { user, loading } = useAuth();
  const { isAdmin } = useAdmin();
  const featuresRef = useRef(null);
  const statsRef = useRef(null);
  const { t } = useTranslation();
  
  // State for counting animations
  const [counting, setCounting] = useState(false);
  
  // State for FAQ section
  const [activeIndex, setActiveIndex] = useState(null);
  
  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };
  
  // Add viewport meta tag for better responsive behavior
  useEffect(() => {
    // Check if the viewport meta tag exists
    let viewportMeta = document.querySelector('meta[name="viewport"]');
    
    // If it doesn't exist, create it
    if (!viewportMeta) {
      viewportMeta = document.createElement('meta');
      viewportMeta.name = 'viewport';
      document.head.appendChild(viewportMeta);
    }
    
    // Set the content to ensure proper responsive behavior
    viewportMeta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
    
    // Cleanup function
    return () => {
      // Restore original viewport settings if needed
      if (viewportMeta) {
        viewportMeta.content = 'width=device-width, initial-scale=1.0';
      }
    };
  }, []);

  // Scroll to features section function
  const scrollToFeatures = () => {
    featuresRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Add intersection observer for stats section
  useEffect(() => {
    const currentStatsRef = statsRef.current; // Store ref in a variable
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setCounting(true);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });
    
    if (currentStatsRef) {
      observer.observe(currentStatsRef);
    }
    
    return () => {
      if (currentStatsRef) {
        observer.unobserve(currentStatsRef);
      }
    };
  }, []);

  return (
    <div className="home-container">
      <LanguageSwitcher />
      
      <div className="home-page">
        <div className="min-h-screen w-full bg-gradient-to-br from-blue-50 to-blue-100">
          <div className="container mx-auto px-4 py-16 flex flex-col lg:flex-row items-center justify-between">
            {/* Hero Content */}
            <div className="flex-1 max-w-2xl lg:pr-8">
              <motion.h1 
                className="text-5xl md:text-6xl font-extrabold leading-tight mb-4 text-gray-900"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
              >
                <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                  Genesixx
                </span> Valley
              </motion.h1>
              
              <motion.p 
                className="text-2xl font-semibold text-blue-600 mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
              >
                {t('home.subtitle')}
              </motion.p>
              
              <motion.p 
                className="text-lg text-gray-600 mb-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
              >
                {t('home.description')}
              </motion.p>
              
              {loading ? (
                <div className="text-lg text-gray-600">{t('common.loading')}</div>
              ) : user ? (
                <motion.div 
                  className="flex flex-col space-y-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.6 }}
                >
                  <p className="text-lg font-medium text-gray-800">
                    {t('dashboard.welcome', { name: user.name || user.email })}
                  </p>
                  <Link 
                    to="/dashboard" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-lg hover:bg-blue-700 transform hover:-translate-y-1 transition-all duration-200"
                  >
                    {t('home.accessDashboard')}
                  </Link>
                  
                  {isAdmin && (
                    <Link 
                      to="/admin/dashboard" 
                      className="inline-flex items-center justify-center px-6 py-3 border-2 border-blue-600 text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-all duration-200"
                    >
                      {t('home.accessAdmin')}
                    </Link>
                  )}
                </motion.div>
              ) : (
                <motion.div 
                  className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.6 }}
                >
                  <Link 
                    to="/login" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-lg hover:bg-blue-700 transform hover:-translate-y-1 transition-all duration-200"
                  >
                    {t('common.login')}
                  </Link>
                  <Link 
                    to="/register" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-white text-blue-600 border-2 border-gray-200 font-semibold rounded-lg hover:border-blue-600 transform hover:-translate-y-1 transition-all duration-200"
                  >
                    {t('common.register')}
                  </Link>
                </motion.div>
              )}
            </div>

            {/* Hero Image */}
            <div className="flex-1 flex justify-center items-center mt-12 lg:mt-0">
              <motion.img 
                src="/resume-preview.svg" 
                alt={t('home.resumePreview')} 
                className="w-full max-w-2xl transform -rotate-3 hover:rotate-0 transition-all duration-300 shadow-2xl rounded-lg"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.7, delay: 0.3 }}
              />
            </div>

            {/* Scroll Arrow */}
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
              <button 
                onClick={scrollToFeatures}
                className="bg-white p-3 rounded-full shadow-lg border-2 border-blue-200 hover:border-blue-400 transition-all duration-300 animate-bounce"
                aria-label={t('home.discoverMore')}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M7 10L12 15L17 10" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div ref={featuresRef} className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-center text-gray-900 mb-12">{t('home.whyChooseUs')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                <div className="text-4xl mb-4">📝</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{t('home.features.modernDesigns')}</h3>
                <p className="text-gray-600">{t('home.features.createQuickly')}</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                <div className="text-4xl mb-4">⚡</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{t('home.features.fastAndSimple')}</h3>
                <p className="text-gray-600">{t('home.features.createQuickly')}</p>
              </div>
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                <div className="text-4xl mb-4">🔄</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{t('home.features.easyUpdate')}</h3>
                <p className="text-gray-600">{t('home.features.modifyAnytime')}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div ref={statsRef} className="py-20 bg-gradient-to-r from-blue-600 to-blue-800">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="p-6">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  <CountUp end={30000} start={counting ? 0 : 30000} />
                </div>
                <div className="text-xl text-blue-100">{t('home.stats.users')}</div>
              </div>
              <div className="p-6">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  <CountUp end={1000} start={counting ? 0 : 1000} />
                </div>
                <div className="text-xl text-blue-100">{t('home.stats.templates')}</div>
              </div>
              <div className="p-6">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  <CountUp end={27000} start={counting ? 0 : 27000} />
                </div>
                <div className="text-xl text-blue-100">{t('home.stats.satisfied')}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials Section */}
        <div className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-center text-gray-900 mb-4">{t('home.testimonials.title', 'What Our Users Say')}</h2>
            <p className="text-xl text-gray-600 text-center mb-12">{t('home.testimonials.description', 'Discover why thousands of professionals trust our platform')}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="text-yellow-400 text-xl mb-4">★★★★★</div>
                <p className="text-gray-600 mb-6">{t('home.testimonials.quote1.testimonial', 'Using this platform transformed my job search. The modern templates and intuitive editor helped me create a CV that stands out. Landed my dream job within 2 weeks!')}</p>
                <div className="flex items-center">
                  <img src="/avatars/testimonial1.jpg" alt="User avatar" className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Mike Bontto</h4>
                    <p className="text-gray-600">{t('home.testimonials.quote1.jobTitle','Student in Politics')}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="text-yellow-400 text-xl mb-4">★★★★★</div>
                <p className="text-gray-600 mb-6">{t('home.testimonials.quote2.testimonial', 'As someone who struggled with creating professional CVs, this tool was a game-changer. Simple, powerful, and the templates are truly impressive. Highly recommended!')}</p>
                <div className="flex items-center">
                  <img src="/avatars/testimonial2.jpg" alt="User avatar" className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Isac Kouyate</h4>
                    <p className="text-gray-600">{t('home.testimonials.quote2.jobTitle','Student in IT')}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="text-yellow-400 text-xl mb-4">★★★★★</div>
                <p className="text-gray-600 mb-6">{t('home.testimonials.quote3.testimonial', 'The ability to quickly update my CV for different applications has been invaluable. The designs are clean, modern, and helped me stand out from other candidates.')}</p>
                <div className="flex items-center">
                  <img src="/avatars/testimonial3.jpg" alt="User avatar" className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Ashley Djoko</h4>
                    <p className="text-gray-600">{t('home.testimonials.quote3.jobTitle','Student in Digital Marketing')}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* FAQ Section */}
        <div className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-center text-gray-900 mb-4">{t('home.faq.title', 'Frequently Asked Questions')}</h2>
            <p className="text-xl text-gray-600 text-center mb-12">{t('home.faq.subTitle', 'Get answers to common questions about our platform')}</p>
            
            <div className="max-w-3xl mx-auto space-y-4">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                  <button 
                    className={`w-full px-6 py-4 text-left flex justify-between items-center bg-white hover:bg-gray-50 transition-colors duration-200 ${
                      activeIndex === index ? 'border-b border-gray-200' : ''
                    }`}
                    onClick={() => toggleFAQ(index)}
                    aria-expanded={activeIndex === index}
                  >
                    <span className="font-semibold text-gray-900">{t(`home.faq.question${index + 1}.question`)}</span>
                    <span className={`text-2xl text-blue-600 transition-transform duration-200 ${
                      activeIndex === index ? 'transform rotate-180' : ''
                    }`}>
                      {activeIndex === index ? '−' : '+'}
                    </span>
                  </button>
                  <div 
                    className={`px-6 py-4 bg-gray-50 transition-all duration-200 ${
                      activeIndex === index ? 'block' : 'hidden'
                    }`}
                    aria-hidden={activeIndex !== index}
                  >
                    <p className="text-gray-600">{t(`home.faq.question${index + 1}.answer`)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Partners Section */}
        <div className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">{t('home.partners.title')}</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                {t('home.partners.description')}
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center justify-items-center">
              <div className="p-4 hover:opacity-75 transition-opacity duration-200">
                <img src="/logos/dv_logo.svg" alt="Diversis" className="h-12 w-auto" />
              </div>
              <div className="p-4 hover:opacity-75 transition-opacity duration-200">
                <img src="/logos/genesixx.png" alt="Genesixx" className="h-12 w-auto" />
              </div>
              <div className="p-4 hover:opacity-75 transition-opacity duration-200">
                <img src="/logos/axis_logo.svg" alt="Axis-Shop" className="h-12 w-auto" />
              </div>
              <div className="p-4 hover:opacity-75 transition-opacity duration-200">
                <img src="/logos/logo-campus-france.png" alt="Campus-france" className="h-12 w-auto" />
              </div>
              <div className="p-4 hover:opacity-75 transition-opacity duration-200">
                <img src="/logos/campus-canada.webp" alt="campus-canada" className="h-12 w-auto" />
              </div>
            </div>
          </div>
        </div>

        <footer className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Genesixx Valley</h3>
                <p className="text-gray-400">{t('home.footer.tagline')}</p>
              </div>
              <div>
                <h4 className="text-lg font-semibold mb-4">{t('home.footer.product')}</h4>
                <ul className="space-y-2">
                  <li><Link to="/features" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.features')}</Link></li>
                  <li><Link to="/templates" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.templates')}</Link></li>
                  <li><Link to="/pricing" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.pricing')}</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-semibold mb-4">{t('home.footer.resources')}</h4>
                <ul className="space-y-2">
                  <li><Link to="/blog" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.blog')}</Link></li>
                  <li><Link to="/guides" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.guides')}</Link></li>
                  <li><Link to="/faq" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.faq')}</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-semibold mb-4">{t('home.footer.company')}</h4>
                <ul className="space-y-2">
                  <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.about')}</Link></li>
                  <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.contact')}</Link></li>
                  <li><Link to="/legal" className="text-gray-400 hover:text-white transition-colors duration-200">{t('home.footer.legal')}</Link></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 pt-8 text-center">
              <p className="text-gray-400">&copy; {new Date().getFullYear()} Genesixx Valley. {t('home.footer.rights')}</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

// CountUp component for animated number counting
function CountUp({ start = 0, end = 0 }) {
  const [count, setCount] = useState(start);
  const duration = 2000; // 2 seconds
  const frames = 60;
  const increment = (end - start) / frames;
  
  useEffect(() => {
    let currentCount = start;
    const timer = setInterval(() => {
      currentCount += increment;
      if (currentCount >= end) {
        clearInterval(timer);
        setCount(end);
      } else {
        setCount(Math.floor(currentCount));
      }
    }, duration / frames);
    
    return () => clearInterval(timer);
  }, [start, end, increment]);
  
  // Format the number with commas
  return new Intl.NumberFormat('fr-FR').format(count);
}

export default Home;